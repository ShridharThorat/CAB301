﻿

public class Scheduler : IScheduler {
	public Scheduler( IJobCollection jobs ) {
		Jobs = jobs;
	}

	public IJobCollection Jobs { get; }

	public IJob[] FirstComeFirstServed() {

        //To be implemented by students

    }

    public IJob[] Priority() {

        //To be implemented by students

    }

    public IJob[] ShortestJobFirst() {

        //To be implemented by students

    }
}